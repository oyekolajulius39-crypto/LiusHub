# 🚀 LIUS HUB - Quick Setup Guide

## ⚡ 3-Step Setup (5 Minutes)

### 1️⃣ Configure Paystack (REQUIRED)
Open `payment.js` and replace line 2:
```javascript
const PAYSTACK_PUBLIC_KEY = 'YOUR_ACTUAL_PAYSTACK_PUBLIC_KEY_HERE';
```
Get your key from: https://dashboard.paystack.com/#/settings/developers

### 2️⃣ Setup Google Sheets Tracking (REQUIRED)
1. Create Google Sheet: https://sheets.google.com
2. Add headers: Timestamp | Full Name | Email | WhatsApp | Cohort | Package | Payment Reference | Amount
3. Extensions > Apps Script > Paste code from README.md
4. Deploy > Web app > Copy URL
5. Paste URL in `payment.js` line 3

### 3️⃣ Upload Logo
Replace `logo-placeholder.svg` with your logo (SVG or PNG recommended)

## 🌐 Deploy in 2 Minutes

### GitHub Pages (Free)
```bash
git init
git add .
git commit -m "Lius Hub website"
git push origin main
# Enable Pages in repo Settings
```

### Netlify (Easiest)
1. Go to netlify.com
2. Drag & drop folder
3. Done! ✨

## 🧪 Test Before Launch

### Test Payment (Paystack Test Mode)
- Card: 4084084084084081
- CVV: 408
- Expiry: Any future date
- PIN: 0000
- OTP: 123456

## ✅ Pre-Launch Checklist
- [ ] Paystack configured
- [ ] Google Sheets connected
- [ ] Logo uploaded
- [ ] Test payment successful
- [ ] Portal access works
- [ ] Mobile responsive checked

## 📞 Need Help?
Read full README.md for detailed instructions and troubleshooting.

---

Built for Lius Hub • Full documentation in README.md
